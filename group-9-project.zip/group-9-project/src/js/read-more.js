const redeMoreBtn = document.querySelectorAll('.about-us__button');
const abMore = document.querySelectorAll('.ab-more');

function toggleBoxRedeMore(e) {
  const index = [...redeMoreBtn].findIndex(item => e.target === item);
  abMore[index].classList.toggle('is-open');
  this.textContent = this.textContent === 'Read more' ? 'less' : 'Read more';
}

redeMoreBtn.forEach(item => item.addEventListener('click', toggleBoxRedeMore));
