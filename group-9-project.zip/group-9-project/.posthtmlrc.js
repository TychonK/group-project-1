module.exports = {
  plugins: {
    'posthtml-include': {
      root: __dirname + '/src',
    },
  },
};
